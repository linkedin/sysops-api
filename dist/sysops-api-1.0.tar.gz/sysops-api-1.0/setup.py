
from distutils.core import setup
setup(name='sysops-api',
      version='1.0',
      py_modules=['CacheExtractor', 'RedisFinder'],
      )
